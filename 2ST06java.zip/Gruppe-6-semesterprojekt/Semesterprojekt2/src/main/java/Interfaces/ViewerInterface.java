package Interfaces;

public interface ViewerInterface {


    void search(String searchString);
    void searchProduction(String searchString);
    void searchCredit(String searchString);

}
