package domain.enums;

public enum Genre {
    DRAMA,
    COMEDY,
    ANNIMATION,
    THRILLER
}
