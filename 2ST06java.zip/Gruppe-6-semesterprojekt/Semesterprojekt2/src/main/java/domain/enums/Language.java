package domain.enums;

public enum Language {
    DANISH,
    ENGLISH,
    GERMAN,
    SPANISH,
    FRENCH,
    ITALIAN
}
