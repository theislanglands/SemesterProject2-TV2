package domain.enums;

public enum ProductionType {
    FILM,
    SERIES

}
